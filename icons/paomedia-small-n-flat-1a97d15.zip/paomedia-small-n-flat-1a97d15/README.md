small-n-flat
============

svg icons on a 24px grid
http://paomedia.github.io/small-n-flat/

![small-n-flat normal size](preview-24.png)
